import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Navigation } from "@/components/ui/navigation";
import { FoodProvider } from "./contexts/FoodContext";
import Dashboard from "./pages/Dashboard";
import FoodTracker from "./pages/FoodTracker";
import SearchFoods from "./pages/SearchFoods";
import DietChatbot from "./pages/DietChatbot";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <FoodProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
        <div className="min-h-screen bg-background">
          <Navigation />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/food-tracker" element={<FoodTracker />} />
            <Route path="/search" element={<SearchFoods />} />
            <Route path="/chat" element={<DietChatbot />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
        </BrowserRouter>
      </FoodProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
